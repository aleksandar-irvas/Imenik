DROP TABLE IF EXISTS `#__imenik_firm`;
